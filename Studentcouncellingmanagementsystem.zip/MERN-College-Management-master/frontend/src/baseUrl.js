export const baseApiURL = () => {
  return process.env.REACT_APP_APILINK;
};
